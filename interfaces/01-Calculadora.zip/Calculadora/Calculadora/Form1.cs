﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
        }

        private void btSumar_Click(object sender, EventArgs e)
        {
            Calcular("+");
        }

        private void btRestar_Click(object sender, EventArgs e)
        {
            Calcular("-");
        }

        private void btMultiplicar_Click(object sender, EventArgs e)
        {
            Calcular("x");
        }

        private void btDividir_Click(object sender, EventArgs e)
        {
            Calcular("/");
        }

        private void Calcular(string operacion)
        {
            try
            {
                double n1 = Convert.ToDouble(tbNumero1.Text);
                double n2 = Convert.ToDouble(tbNumero2.Text);

                double resultado = 0;
                switch(operacion)
                {
                    case "+": resultado = n1 + n2; break;
                    case "-": resultado = n1 - n2; break;
                    case "x": resultado = n1 * n2; break;
                    case "/":
                        if (n2 == 0)
                        {
                            FormAviso a = new FormAviso();
                            a.SetTexto("No se puede dividir entre cero!");
                            a.ShowDialog();
                        }

                        else
                            resultado = n1 / n2; break;
                }
                lbResultado.Text = Convert.ToString(resultado);
            }
            catch (FormatException)
            {
                MessageBox.Show("Dato no numérico", "Aviso");
            }

        }
    }
}
