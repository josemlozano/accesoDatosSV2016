﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class FormAviso : Form
    {
        public FormAviso()
        {
            InitializeComponent();
        }

        public void SetTexto(string t)
        {
            lbAviso.Text = t;
        }
    }
}
