package sportmanagerlayers;

public class Deporte {
    
    public Deporte(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }
    public String codigo;
    public String nombre;
}
