package sportmanagerlayers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class SportManagerLayers {

    public void showMenu() {
        System.out.println("1. Añadir deporte");
        System.out.println("2. Añadir deportistas");
        System.out.println("3. Buscar por nombre de deportista");
        System.out.println("0. Salir");
        System.out.print("Elige una opción: ");
    }
    
    public void anyadirDeporte(String url, String usuario, String password) {
        Scanner scan = new Scanner(System.in);

        System.out.print("Código deporte: ");
        String cod = scan.nextLine();
        System.out.print("Nombre deporte: ");
        String nombre = scan.nextLine();

        ListaDeportes ld = new ListaDeportes();
        boolean correcto = ld.anyadir(new Deporte(cod, nombre));

        if (correcto) {
            System.out.println("Datos guardados correctamente.");
        }
        else {
            System.out.println("Error al guardar los datos");
        }
    }
    
    public void anyadirDeportista(String url, String usuario, String password) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Código deportista: ");
        String cod = scan.nextLine();
        System.out.print("Nombre deportista: ");
        String nombre = scan.nextLine();
        System.out.print("Código deporte: ");
        String codDeport = scan.nextLine();

        ListaDeportistas ld = new ListaDeportistas();
        boolean correcto = ld.anyadir(
            new Deportista(cod, nombre, new Deporte(codDeport, "")));

        if (correcto) {
            System.out.println("Datos guardados correctamente.");
        }
        else {
            System.out.println("Error al guardar los datos");
        }
                    
    }
    
    public void buscarPorNombreDeportista(String url, String usuario,
            String password) {
        try {
            Scanner scan = new Scanner(System.in);
            
            System.out.print("Nombre deportista: ");
            String nombre = scan.nextLine().toUpperCase();
            Connection con = DriverManager.getConnection(url, usuario, password);
            String sql = "select dep.nombre, dep.cod, d.nombre from deportistas " +
                "dep left join deportes d on (dep.coddeporte = d.cod) where " +
                "upper(dep.nombre) like '%" + nombre + "%'";
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            
            if (rs.isBeforeFirst()) {
                while (rs.next()) {
                    System.out.println("Nombre: " + rs.getString(1) + " Código: " +
                        rs.getString(2) + " Deporte: " + rs.getString(3));
                }
            }
            else {
                System.out.println("No existe deportistas con nombre parecido" +
                    " al introducido");
            }
            rs.close();
            con.close();
        }
        catch (SQLException e) {
            System.out.println("Error en la consulta de datos");
        }
        catch (Exception e) {
            System.out.println("Error inesperado: " + e.getMessage());
        }
    }
    
    public static void main(String[] args) throws ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");

        
        Scanner scan = new Scanner(System.in);
        String option;
        SportManagerLayers sportManager = new SportManagerLayers();
        
        do {
            sportManager.showMenu();
            option = scan.nextLine();
            switch (option) {
                case "0":
                    System.out.println("Adiós");
                    break;
                case "1":
                    sportManager.anyadirDeporte();
                    break;
                case "2":
                    sportManager.anyadirDeportista(url, usuario, password);
                    break;
                case "3":
                    sportManager.buscarPorNombreDeportista(url, usuario, 
                        password);
                    break;
                default:
                    System.out.println("Opción no válida");
                    break;
            }
        }
        while (!option.equals("0"));
    }    
}
