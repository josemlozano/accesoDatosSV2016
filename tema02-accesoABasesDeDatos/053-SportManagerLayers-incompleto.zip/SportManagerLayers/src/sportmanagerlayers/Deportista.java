package sportmanagerlayers;

public class Deportista {
    
    public Deportista(String codigo, String nombre, Deporte d) {
        this.codigo = codigo;
        this.nombre = nombre;
        deporte = d;
    }
    
    public String codigo;
    public String nombre;
    public Deporte deporte;
}
