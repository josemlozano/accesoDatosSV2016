package sportmanagerlayers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ListaDeportistas {
    
    String url = "jdbc:mysql://localhost/dia26";
    String usuario = "root";
    String password = "root";
    
    public boolean anyadir(Deportista d)
    {
        try {
            Connection con = DriverManager.getConnection(url, usuario, password);
            
            String sql = "insert into deportistas (cod, nombre, codDeporte)" +
                " values ('" + d.codigo + "', '" + d.nombre + "', ";
            
            if (d.deporte.codigo.equals("")) {
                sql += "null)";
            }
            else {
                sql += ("'" + d.deporte.codigo + "')");
            }
            
            Statement statement = con.createStatement();
            int filasAlmacenadas = statement.executeUpdate(sql);
            con.close();
            
            if (filasAlmacenadas > 0) {
                // System.out.println("Datos guardados correctamente.");
                return true;
            }
            else {
                // System.out.println("Error al guardar los datos");
                return false;
            }
        }
        catch (SQLException e) {
            //System.out.println("Error en el guardado de datos");
            return false;
        }
        catch (Exception e) {
            //System.out.println("Error inesperado: " + e.getMessage());
            return false;
        }
    }
}
