/**
 * @author chao
 */

package swing01;

public class Swing01 {

    public static void main(String[] args) {
        NewJFrame frame = new NewJFrame();
        frame.setVisible(true);
    }
    
}
