package manejadorclientes;

import java.util.Calendar;
import java.util.Objects;

/**
 * @author chao
 */
public class Producto {
    private int codigo;
    private String referencia;
    private String nombre;
    private int stockMinimo;
    private Calendar fechaAlta;
    private boolean activo;
    private String comentarios;
    private String fabricacion;

    public Producto(int codigo, String referencia, String nombre, int stockMinimo, 
            Calendar fechaAlta, boolean activo, String comentarios, String fabricacion) {
        this.codigo = codigo;
        this.referencia = referencia;
        this.nombre = nombre;
        this.stockMinimo = stockMinimo;
        this.fechaAlta = fechaAlta;
        this.activo = activo;
        this.comentarios = comentarios;
        this.fabricacion = fabricacion;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(int stockMinimo) {
        this.stockMinimo = stockMinimo;
    }

    public Calendar getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Calendar fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public String getFabricacion() {
        return fabricacion;
    }

    public void setFabricacion(String fabricacion) {
        this.fabricacion = fabricacion;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Producto other = (Producto) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.referencia, other.referencia)) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (this.stockMinimo != other.stockMinimo) {
            return false;
        }
        if (!Objects.equals(this.fechaAlta, other.fechaAlta)) {
            return false;
        }
        if (this.activo != other.activo) {
            return false;
        }
        if (!Objects.equals(this.comentarios, other.comentarios)) {
            return false;
        }
        if (!Objects.equals(this.fabricacion, other.fabricacion)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Producto{" + "codigo=" + codigo + ", referencia=" + referencia + 
            ", nombre=" + nombre + ", stockMinimo=" + stockMinimo + ", fechaAlta=" + 
            (fechaAlta.getTime().getMonth() + 1) + "/" +
            (fechaAlta.getTime().getYear() + 1900) + ", activo=" + activo + 
            ", comentarios=" + comentarios + ", fabricacion=" + fabricacion + '}';
    }
}
