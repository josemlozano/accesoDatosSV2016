package manejadorclientes;

import java.util.Calendar;
import java.util.List;
import java.util.Objects;

/**
 * @author chao
 */
public class Cliente {
    protected String codigo;
    protected String nombre;
    protected float descuento;
    protected Calendar fechaAlta;
    protected List<String> direccion;

    public Cliente(String codigo, String nombre, float descuento, 
            Calendar fechaAlta, List<String> direccion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.descuento = descuento;
        this.fechaAlta = fechaAlta;
        this.direccion = direccion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getDescuento() {
        return descuento;
    }

    public void setDescuento(float descuento) {
        this.descuento = descuento;
    }

    public Calendar getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Calendar fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public List<String> getDireccion() {
        return direccion;
    }

    public void setDireccion(List<String> direccion) {
        this.direccion = direccion;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (Float.floatToIntBits(this.descuento) != Float.floatToIntBits(other.descuento)) {
            return false;
        }
        if (!Objects.equals(this.fechaAlta, other.fechaAlta)) {
            return false;
        }
        if (!Objects.equals(this.direccion, other.direccion)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Cliente{" + "codigo=" + codigo + ", nombre=" + nombre + 
            ", descuento=" + descuento + ", fechaAlta=" + (fechaAlta.getTime().getMonth() + 1) + "/" +
            (fechaAlta.getTime().getYear() + 1900) + ", direccion=" + direccion + '}';
    }
}
