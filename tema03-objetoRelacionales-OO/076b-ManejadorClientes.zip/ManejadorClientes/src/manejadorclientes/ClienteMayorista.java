package manejadorclientes;

import java.util.Calendar;
import java.util.List;

/**
 * @author chao
 */
public class ClienteMayorista extends Cliente {
    private int volumenParaDescuento;
    private float descuentoAdicional;
    
    public ClienteMayorista(String codigo, String nombre, float descuento, 
            Calendar fechaAlta, List<String> direccion, int volumenParaDescuento,
            float descuentoAdicional) {
        super(codigo, nombre, descuento, fechaAlta, direccion);
        this.volumenParaDescuento = volumenParaDescuento;
        this.descuentoAdicional = descuentoAdicional;
    }

    public int getVolumenParaDescuento() {
        return volumenParaDescuento;
    }

    public void setVolumenParaDescuento(int volumenParaDescuento) {
        this.volumenParaDescuento = volumenParaDescuento;
    }

    public float getDescuentoAdicional() {
        return descuentoAdicional;
    }

    public void setDescuentoAdicional(float descuentoAdicional) {
        this.descuentoAdicional = descuentoAdicional;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        super.equals(obj);
        
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ClienteMayorista other = (ClienteMayorista) obj;
        if (this.volumenParaDescuento != other.volumenParaDescuento) {
            return false;
        }
        if (Float.floatToIntBits(this.descuentoAdicional) != 
                Float.floatToIntBits(other.descuentoAdicional)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ClienteMayorista{" + "codigo=" + codigo + ", nombre=" + nombre + 
            ", descuento=" + descuento + ", fechaAlta=" + (fechaAlta.getTime().getMonth() + 1) + "/" +
            (fechaAlta.getTime().getYear() + 1900) + ", direccion=" + direccion +
            ", volumenParaDescuento=" + volumenParaDescuento + ", descuentoAdicional=" + 
            descuentoAdicional + '}';
    }
}
